# gui/main_window.py
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QPushButton, QLabel
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtCore import Qt
from models.network import Network
from core.database import Database
from core.network_scanner import NetworkScanner
from config.config import Config

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = Config()
        self.database = Database()
        self.network_scanner = NetworkScanner()
        self.init_ui()

    def init_ui(self):
        self.setGeometry(100, 100, 800, 600)
        self.setWindowTitle("Wi-Fi Scanner")
        self.setStyleSheet(open(self.config.get_stylesheet()).read())
        self.background_label = QLabel(self)
        self.background_label.setPixmap(QPixmap(self.config.get_background_image()))
        self.background_label.setGeometry(0, 0, 800, 600)
        self.table_widget = QTableWidget()
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(5)
        self.table_widget.setHorizontalHeaderLabels(["BSSID", "Channel", "RSSI", "ESSID", "Security"])
        self.table_widget.setFont(QFont("Arial", 12))
        self.table_widget.setGeometry(50, 50, 700, 400)
        self.scan_button = QPushButton("Scan Networks", self)
        self.scan_button.setGeometry(50, 500, 200, 50)
        self.scan_button.setFont(QFont("Arial", 12))
        self.scan_button.clicked.connect(self.scan_networks)
        self.crack_button = QPushButton("Crack Password", self)
        self.crack_button.setGeometry(300, 500, 200, 50)
        self.crack_button.setFont(QFont("Arial", 12))
        self.crack_button.clicked.connect(self.crack_password)

    def scan_networks(self):
        networks = self.network_scanner.scan_networks()
        self.table_widget.setRowCount(len(networks))
        for i, network in enumerate(networks):
            self.table_widget.setItem(i, 0, QTableWidgetItem(network.bssid))
            self.table_widget.setItem(i, 1, QTableWidgetItem(network.channel))
            self.table_widget.setItem(i, 2, QTableWidgetItem(network.rssi))
            self.table_widget.setItem(i, 3, QTableWidgetItem(network.essid))
            self.table_widget.setItem(i, 4, QTableWidgetItem(network.security))

    def crack_password(self):
        # TO DO: implement password cracking logic
        pass

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())