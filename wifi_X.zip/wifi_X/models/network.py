# models/network.py
class Network:
    def __init__(self, bssid, channel, rssi, essid, security):
        self.bssid = bssid
        self.channel = channel
        self.rssi = rssi
        self.essid = essid
        self.security = security