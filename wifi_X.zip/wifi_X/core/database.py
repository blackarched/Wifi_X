# core/database.py
import sqlite3
from config.config import Config

class Database:
    def __init__(self):
        self.config = Config()
        self.conn = sqlite3.connect(self.config.get_database_file())
        self.cursor = self.conn.cursor()

    def create_table(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS networks (
                id INTEGER PRIMARY KEY,
                bssid TEXT,
                channel TEXT,
                rssi TEXT,
                essid TEXT,
                security TEXT
            );
        """)
        self.conn.commit()

    def insert_network(self, network):
        self.cursor.execute("""
            INSERT INTO networks (bssid, channel, rssi, essid, security)
            VALUES (?,?,?,?,?);
        """, (network.bssid, network.channel, network.rssi, network.essid, network.security))
        self.conn.commit()

    def get_networks(self):
        self.cursor.execute("SELECT * FROM networks;")
        return self.cursor.fetchall()
