# core/password_cracker.py
import subprocess
from config.config import Config

class PasswordCracker:
    def __init__(self):
        self.config = Config()

    def crack_password(self, network):
        command = [self.config.get_aircrack_ng_path(), "-w", self.config.get_wordlist_file(), "-b", network.bssid, "capture-01.cap"]
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()
        if error:
            raise Exception(error.decode("utf-8"))
        return output.decode("utf-8")
