# core/utils.py
import os
import sys

def get_interface():
    return os.popen("iw dev").read().splitlines()[0].split()[1]

def get_aircrack_ng_path():
    return "/usr/bin/aircrack-ng"

def get_airodump_ng_path():
    return "/usr/bin/airodump-ng"