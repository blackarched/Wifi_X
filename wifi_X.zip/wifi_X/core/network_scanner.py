# core/network_scanner.py
import subprocess
from config.config import Config
from models.network import Network

class NetworkScanner:
    def __init__(self):
        self.config = Config()

    def scan_networks(self):
        command = [self.config.get_airodump_ng_path(), "-w", "capture", "--channel", "1-14", self.config.get_interface()]
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()
        if error:
            raise Exception(error.decode("utf-8"))
        networks = []
        for line in output.decode("utf-8").splitlines():
            if "ESSID" in line:
                bssid = line.split()[0]
                channel = line.split()[1]
                rssi = line.split()[2]
                essid = line.split()[3]
                security = line.split()[4]
                network = Network(bssid, channel, rssi, essid, security)
                networks.append(network)
        return networks