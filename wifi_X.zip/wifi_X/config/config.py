# config/config.py
import os

class Config:
    def __init__(self):
        self.interface = "wlan0"
        self.database_file = "networks.db"
        self.wordlist_file = "wordlist.txt"
        self.aircrack_ng_path = "/usr/bin/aircrack-ng"
        self.airodump_ng_path = "/usr/bin/airodump-ng"
        self.background_image = "resources/images/background.png"
        self.button_image = "resources/images/button.png"
        self.icon_image = "resources/images/icon.png"
        self.stylesheet = "resources/styles/cyberpunk.css"

    def get_interface(self):
        return self.interface

    def get_database_file(self):
        return self.database_file

    def get_wordlist_file(self):
        return self.wordlist_file

    def get_aircrack_ng_path(self):
        return self.aircrack_ng_path

    def get_airodump_ng_path(self):
        return self.airodump_ng_path

    def get_background_image(self):
        return self.background_image

    def get_button_image(self):
        return self.button_image

    def get_icon_image(self):
        return self.icon_image

    def get_stylesheet(self):
        return self.stylesheet